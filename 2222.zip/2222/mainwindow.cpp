#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QPainter>
#include<QPaintEvent>
#include<QPushButton>
#include<QDebug>

#include"towerposition.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    this->setFixedSize(1200,600);
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::loadTowerPositions()
{
    QPoint pos[] =
    {
        QPoint(65, 220),
        QPoint(155, 220)
    };
    int len	= sizeof(pos) / sizeof(pos[0]);

    for (int i = 0; i < len; ++i)
        m_towerPositionsList.push_back(pos[i]);
}



void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/back.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}








